package com.smartbank.service;
import org.springframework.beans.factory.annotation.Autowired;

import com.smartbank.dao.UserDao;
import com.smartbank.model.User;

public class UserService {
	
	@Autowired
	private UserDao userDAO;
 


		 
		public void addUser(User user) {
			  userDAO.addUser(user);  
			
		}
		
		
		public User getUser(int id)
		{
			
			User user=userDAO.getUser(id);
			return user;
		} 
		

}
