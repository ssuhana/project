package com.smartbank.dao;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;

import com.smartbank.model.User;

public class UserDao {
	
	@Autowired
	private	 SessionFactory sessionFactory;
	 
	 
	 
	public void addUser(User user) {
		   
		 Session session=sessionFactory.openSession();
		  Transaction tx=session.beginTransaction();
		  session.save(user);
		  tx.commit();
		  session.close(); 
	  }
	
	
	public User getUser(int id)
	{
		User user1=null;
		Session session=sessionFactory.openSession();
		 String hql="from User where id="+id;
	  	 Query query = session.createQuery(hql);
	  	 
	  	 List<User> list=query.getResultList();
	  	 
	  	 for (User u:list)
	  	 {
	  		 user1=u; 
	  	 }
	  	 
	  	 return user1;
	  	       
	}
}
	