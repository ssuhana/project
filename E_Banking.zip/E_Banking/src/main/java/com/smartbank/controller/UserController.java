package com.smartbank.controller;

import javax.validation.Valid;

//import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
 

import com.smartbank.model.User;
import com.smartbank.service.UserService;

@Controller
public class UserController {
	@Autowired
	private UserService userService;
	@RequestMapping("toAdd")
	public String add(Model m)
	{
		
		m.addAttribute("userBean", new User());
		return "login";
	}
	@RequestMapping(value="/doAdd", method = RequestMethod.POST)
	public String saveUser(@ModelAttribute("userBean")User userBean,BindingResult result,Model m)
	{
		 if (result.hasErrors())
			 {
	
			  return "login";
			 }
	 else
	 {
		m.addAttribute("user", userBean);
  		userService.addUser(userBean); 
  		System.out.println("u  "+userBean);
  		  
	  return "welcome";
		
		
	}
	}
	
	
	@RequestMapping("getId")
		 public ModelAndView delete()
		 {
			 
			 return new ModelAndView("delete");
		 }
	
	
	@RequestMapping("toDelete")
public String toDelete(@RequestParam("id") int id,User user,Model m)
{
	
	user=userService.getUser(id);
	m.addAttribute("deleteBean",user);
	return "show";
	
}
	
//	@RequestMapping(value="deleteEmployee",method=RequestMethod.POST)
//	public String delete(User user)
//	{
//		int k=userService.delete( user);
//		return "final";
		
	}
	
 
